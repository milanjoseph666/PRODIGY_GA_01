
# GPT-2 Text Generation Fine-Tuning Task

This project demonstrates how to fine-tune GPT-2 using HuggingFace Transformers and Google Colab.

## References
1. HuggingFace Blog: https://huggingface.co/blog/how-to-generate
2. Google Colab Notebook: https://colab.research.google.com/drive/15qBZx5y9rdaQSyWpsreMDnTiZ5IlN0zD

## Files
- `gpt2_finetune.py`: Python script to load and fine-tune GPT-2 on a custom dataset.
- `generate_text.py`: Script to generate text from the fine-tuned model.
- `dataset.txt`: Sample custom dataset.
